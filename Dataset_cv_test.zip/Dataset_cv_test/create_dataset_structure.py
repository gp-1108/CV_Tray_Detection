import os

# Opening the true_labels.txt file
true_labels = open("true_labels.txt", "r")
# For each line in the file move the corresponding image to the corresponding folder
for line in true_labels:
  # Remove the \n at the end of the line
  line = line.strip()
  # Split the line into the image name and the label
  image_name, label = line.split(",")
  label.replace(" ", "_")
  # Create the folder if it doesn't exist
  if not os.path.exists(label):
    os.makedirs(label)
  # Move the image to the folder
  os.rename(image_name, label + "/" + image_name)

# Close the file
true_labels.close()