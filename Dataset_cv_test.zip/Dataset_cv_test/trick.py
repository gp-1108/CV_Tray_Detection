import os

# Rename all folders by replacing spaces with underscores
for folder in os.listdir():
  if os.path.isdir(folder):
    new_folder = folder.replace(" ", "_")
    os.rename(folder, new_folder)

